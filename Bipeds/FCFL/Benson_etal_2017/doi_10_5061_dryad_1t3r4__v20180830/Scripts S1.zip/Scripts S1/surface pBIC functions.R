## version of surfaceF and surfaceB that uses pBIC, rather than AICc #
# new part is pBIC_surface() which computes pBIC from surface output
# rest is just tweaks to SURFACE code to use pBIC instead of AICc
# haven't tested non-default options #

### 2017-06-15 Gene Hunt, with Roger Benson
### used in Benson et al ms on Dinosaur body size evolution


library(surface)


runSurface_pBIC<- function(tree, dat, exclude = 0, aic_threshold = 0, max_steps = NULL, 
    verbose = FALSE, plotaic = FALSE, error_skip = FALSE, only_best = FALSE, 
    sample_shifts = FALSE, sample_threshold = 2)
{
    if (class(tree) != "phylo") 
        stop("'tree' must by a 'phylo' formatted phylogenetic tree")
    if (is.null(tree$node.label)) 
        stop("Each node in 'tree' must have a unique label for back-compatibility between formats. Use 'nameNodes(tree)'. ")
    if (any(duplicated(tree$node.label))) 
        stop("Each node in 'tree' must have a unique label for back-compatibility between formats. Use 'nameNodes(tree)'. ")
    if (!is.data.frame(dat)) 
        stop("'dat' must be formatted as a data frame with row names corresponding to the tip labels in 'tree'")
    olist <- convertTreeData(tree, dat)
    otree <- olist[[1]]
    odata <- olist[[2]]
    fwd <- surfaceForward_pBIC(otree, odata, tree, exclude = exclude, max_steps = max_steps,
    	verbose = verbose, plotaic = plotaic, error_skip = error_skip, sample_shifts = sample_shifts, 
        sample_threshold = sample_threshold)
    bwd <- surfaceBackward_pBIC(otree, odata, tree, fwd[[length(fwd)]], 
        aic_threshold = aic_threshold, verbose = verbose, plotaic = plotaic, 
        error_skip = error_skip, only_best = only_best, sample_shifts = sample_shifts, 
        sample_threshold = sample_threshold)
    return(list(fwd = fwd, bwd = bwd))
}


runSurface_AICc_pBIC<- function(tree, dat, exclude = 0, aic_threshold = 0, max_steps = NULL, 
    verbose = FALSE, plotaic = FALSE, error_skip = FALSE, only_best = FALSE, 
    sample_shifts = FALSE, sample_threshold = 2)
{
    if (class(tree) != "phylo") 
        stop("'tree' must by a 'phylo' formatted phylogenetic tree")
    if (is.null(tree$node.label)) 
        stop("Each node in 'tree' must have a unique label for back-compatibility between formats. Use 'nameNodes(tree)'. ")
    if (any(duplicated(tree$node.label))) 
        stop("Each node in 'tree' must have a unique label for back-compatibility between formats. Use 'nameNodes(tree)'. ")
    if (!is.data.frame(dat)) 
        stop("'dat' must be formatted as a data frame with row names corresponding to the tip labels in 'tree'")
    olist <- convertTreeData(tree, dat)
    otree <- olist[[1]]
    odata <- olist[[2]]
    fwd <- surfaceForward(otree, odata, exclude = exclude, max_steps = max_steps,
    	verbose = verbose, plotaic = plotaic, error_skip = error_skip, sample_shifts = sample_shifts, 
        sample_threshold = sample_threshold)
    bwd <- surfaceBackward_pBIC(otree, odata, tree, fwd[[length(fwd)]], 
        aic_threshold = aic_threshold, verbose = verbose, plotaic = plotaic, 
        error_skip = error_skip, only_best = only_best, sample_shifts = sample_shifts, 
        sample_threshold = sample_threshold)
    return(list(fwd = fwd, bwd = bwd))
}


surfaceForward_pBIC<- function(otree, odata, tree, starting_list = NULL, starting_shifts = NULL, 
    exclude = 0, aic_threshold = 0, max_steps = NULL, verbose = FALSE, plotaic = FALSE, 
    error_skip = FALSE, sample_shifts = FALSE, sample_threshold = 2)
{
    if (any(duplicated(as(otree, "data.frame")$labels))) 
        stop("Each node in 'tree' must have a unique label for back-compatibility between formats. Use 'nameNodes(tree)' prior to converting to ouch format")
    n <- otree@nterm
    nt <- dim(odata)[2]
    if (is.null(max_steps)) 
        max_steps <- otree@nnodes
    if (is.null(starting_list)) {
        out_list <- startingModel(otree, odata, starting_shifts)
        out_list[[1]]$pbic<- pBIC_surface(out_list[[1]], tree)
    }
    else {
        out_list <- starting_list
    }
    for (j in (length(out_list) + 1):max_steps) {  	
    	#cat("f", j, "\n")
        out_list[[j]] <- addRegime(otree, odata, oldshifts = out_list[[j - 
            1]]$savedshifts, oldfit = out_list[[j - 1]]$fit, 
            oldaic = out_list[[j - 1]]$aic, alloldaic = out_list[[j - 
                1]]$all_aic, exclude = exclude, aic_threshold = 0, 
            verbose = verbose, plotaic = plotaic, error_skip = error_skip, 
            sample_shifts = sample_shifts, sample_threshold = sample_threshold)
        
        # add here pBIC calculation
        pbic<- pBIC_surface(out_list[[j]], tree, phase="forward")
        out_list[[j]]$pbic <- pbic
			        
        # modified to check pBIC rather than AICc
        if ((out_list[[j]]$pbic - out_list[[j - 1]]$pbic) >= 0) 
            break
    } # end for loop

    if ((out_list[[j]]$pbic - out_list[[j - 1]]$pbic) >= 0) {
        out_list <- out_list[1:(j - 1)]
    }
    
    return(out_list)
}

surfaceBackward_pBIC<- function (otree, odata, tree, starting_model, aic_threshold = 0, max_steps = NULL, 
    verbose = FALSE, only_best = FALSE, plotaic = FALSE, error_skip = FALSE, sample_shifts = FALSE, 
    sample_threshold = 2) 
{
    if (any(duplicated(as(otree, "data.frame")$labels))) 
        stop("Each node in 'tree' must have a unique label for back-compatibility between formats. Use 'nameNodes(tree)' prior to converting to ouch format")
    n <- otree@nterm
    nt <- dim(odata)[2]
    if (is.null(max_steps)) 
        max_steps <- starting_model$n_regimes[1]
    back_list <- list()
    back_list[[1]] <- list(fit = starting_model$fit, delta_aic = NULL, 
        aic = starting_model$aic, savedshifts = starting_model$savedshifts, 
        n_regimes = starting_model$n_regimes, pbic = starting_model$pbic)
        pbic<- pBIC_surface(back_list[[1]], tree, phase="backward")
        back_list[[1]]$pbic <- pbic        
        
    for (j in 2:max_steps) {
    	#cat("b", j, "\n")
        back_list[[j]] <- collapseRegimes(otree, odata, oldshifts = back_list[[j - 
            1]]$savedshifts, oldaic = back_list[[j - 1]]$aic, 
            oldfit = back_list[[j - 1]]$fit, aic_threshold = aic_threshold, 
            verbose = verbose, only_best = only_best, plotaic = plotaic, 
            error_skip = error_skip, sample_shifts = sample_shifts, 
            sample_threshold = sample_threshold)
	
        # add here pBIC calculation
        pbic<- pBIC_surface(back_list[[j]], tree, phase="backward")
        back_list[[j]]$pbic <- pbic
        
        # modified to check pBIC rather than AICc        
        if ((back_list[[j]]$pbic - back_list[[j - 1]]$pbic) >= 0) 
            break
    }	# end for loop

    if (back_list[[j]]$pbic < back_list[[j - 1]]$pbic) {
        back_list <- back_list[1:(j - 1)]
    }
    return(back_list)
}




 # calculates pBIC from SURFACE output
 # surf_out is an element of fwd or bwd; tree is tree in phylo format
 pBIC_surface<- function(surf_out, tree, phase=c("backward","forward"), addedCols=1, root=c("fixed", "stationary"))
 {
 	# preliminaries
 	root<- match.arg(root)
 	phase<- match.arg(phase) 
 	data<- surf_out[[1]][[1]]@data[[1]]	# note only works for 1D data
 	nn<- sum(is.na(data))		# number of internal nodes
 	nt<- sum(!is.na(data))		# number of tips
 	nodelab<- surf_out[[1]][[1]]@nodelabels
 	inodes<- 1:nn
 	tnodes<- (nn+1):(nn+nt)
	nu<- var(data, na.rm=TRUE)	# trait variance, needed for scaling
	alpha<- surf_out[[1]][[1]]@sqrt.alpha^2
	vstep<- surf_out[[1]][[1]]@sigma^2
	
	# get shift infromation
	if(phase == "forward")	shifts<- surf_out$savedshifts[-1]	# omit the first 'shift' which is just the root
	if(phase == "backward"){
			ss<- surf_out$savedshifts	# need to get "one column per distinct optimum value"
			uu<- unique(ss)
			sub<- c()
			for (k in 1:length(uu))	sub[k]<- match(uu[k], ss)
			#print(sub)
			shifts<- ss[sub][-1]		# at end, drop initial 'shift' which is root value				
			}
	
	
	bc<- names(shifts)		# branches with shifts as char
	bn<- as.numeric(bc)
	ns<- length(shifts)
	logL<- surf_out[[1]][[1]]@loglik
	pBIC<- -2*logL + 2*ns*log(2*nt - 3) + 2*log(nt)	# only first part, not incl. shifts
	otree<- ouchtree(surf_out[[1]][[1]]@nodes, surf_out[[1]][[1]]@ancestors, surf_out[[1]][[1]]@times, surf_out[[1]][[1]]@nodelabels)
	
	## set-up design matrix ## 
	# col vector(s) of ones, needed even if no shifts
	a1<- matrix(1, nrow=nt, ncol=addedCols)	
	colnames(a1)<- paste0("added", 1:addedCols)

	Xd<- matrix(0, nrow=nt, ncol=ns)
	rownames(Xd)<- nodelab[tnodes]
	colnames(Xd)<- c(bc)

	# compute design matrix
	if(ns > 0){
		for(i in 1:ns){
			foc<- bn[i]	# focal node
			alld<- ouchDescendants(foc, otree)
			if(is.na(alld[1])) {		# shifts on terminal branches
				ancb<- as.numeric(otree@ancestors[foc])
				dt<- otree@times[foc] - otree@times[ancb]
				dlab<- nodelab[foc]
				Xd[dlab,i]<- 1 - exp(-alpha*dt)
				}
			else{						# shifts on internal branches
				dtips<- alld[alld %in% tnodes]
				dlab<- nodelab[dtips]
				dt<- otree@times[dtips] - otree@times[foc]
				Xd[dlab,i]<- 1 - exp(-alpha*dt)		
				}
		}
	}

	


	# now, combine Xd and a1 as needed
	if(ns==0)	X<- a1	else X<- cbind(a1, Xd)
	
	# get VCV matrix
	S<- matrix(nrow=nt, ncol=nt)
	V<- otree@branch.times
	D<- cophenetic(tree)	# patristic distances, but in ape not ouch order
	Do<- D[nodelab[tnodes], nodelab[tnodes]]	# now in ouch order
	rownames(S)<- colnames(S)<- rownames(V)<- colnames(V)<- nodelab[tnodes]
	
	if(root == "fixed")		S<- (1 - exp(-2*alpha*V)) * exp(-alpha*Do) * (vstep/(2*alpha))
	if(root == "stationary")	S<- exp(-alpha*Do) * (vstep/(2*alpha))
	
	## pull all parts together ##
	mat <- t(X) %*% solve(S/nu) %*% X
	logD<- determinant(mat, log=TRUE)$modulus
	pBIC<- pBIC + as.vector(logD)
	
	return(pBIC)  	
 }

 # plots from output of runSurface_pBIC
 surfacePBICplot<- function(rs)
 {
  pbicF<- 	sapply(rs$fwd, FUN=function(m) m$pbic)
  pbicB<-  sapply(rs$bwd, FUN=function(m) m$pbic)
  pbics<- c(pbicF, pbicB)
  
  nrF<- sapply(rs$fwd, FUN=function(m) m$n_regimes)
  nrB<- sapply(rs$bwd, FUN=function(m) m$n_regimes)
  nrs<- c(nrF["kprime",], nrB["kprime",])
  
  plot(nrs, pbics, typ="o")
  	
 }
