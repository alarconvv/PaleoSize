# functions to estimate standard errors of variables estimated through regression #
# uses simulation to incorporate error in estimation of trait means, and error from regression #
# 2015-09-14 Gene Hunt, with Roger Benson #
 
 
 ## The variable of interest is Y [here, body mass]
 ## Y can be directly estimated from X variable(s) [here, circumference of femur 
 ##		and (sometimes) humerus]
 ## When X variables are not available, they can be estimated from W variables [here, 
 ##		other dimensions of the limbs], which are then used to estimate Y
  
 
 require(compositions)

 # standard error of slope; needed by other functions 
 # x is the independent (x) variable of the regression
 SEslope<- function(reg, x)
 	{
 	 n<- length(x)
 	 sig<- var(reg) #sum(resid(reg)^2)/(n-2)	# estimate of residual variance, sigma
 	 se<- sqrt(sig / ( (n-1)*sd(x) ) )
 	 
 	 return(se)	
 	}
 

 
 # regYX and regXW must be lm (not gls!) objects
 # Wvar is the error variance (=SE^2) of W; the default represents n = 1, CV = 5 on original scale, log10 transform
 SE.YfromW.sim<- function(N=1e4, wo, regYX, regXW, Wvar=0.000471)
 {
 	# get distribution of Ws, and slopes
 	ws<- rnorm(N, wo, sqrt(Wvar))
   	bw<- coef(regXW)  # observed slopes
	bx<- coef(regYX)
 	bxs<- rnorm(N, bx[2], SEslope(regYX))		
 	bws<- rnorm(N, bw[2], SEslope(regXW))
 	
 	# generate fake y's from w's and slopes #
 	# y = b_yx * x + eps_yx, then substitute x = b_wx * ws + eps_wx
 	yf<- bxs * (bws * ws + rnorm(N, 0, sqrt(var(regXW)))) + rnorm(N, 0, sqrt(var(regYX)))
 	return(sd(yf))
 }

 # SE when both X1 and X2 are estimated from W1 and W2, respectively, and then Y ~ I(X1+X2)
 SE.YfromW1W2.sim<- function(N=1e4, w1o, w2o, regYX, regX1W1, regX2W2, W1var=0.000471, W2var=0.000471)
 {
 	# get distribution of Ws, and slopes
 	w1s<- rnorm(N, w1o, sqrt(W1var))
 	w2s<- rnorm(N, w2o, sqrt(W2var))

   	bw1<- coef(regX1W1)  # observed slopes
   	bw2<- coef(regX2W2)  
	bx<- coef(regYX)
 	bxs<- rnorm(N, bx[2], SEslope(regYX))		
 	bw1s<- rnorm(N, bw1[2], SEslope(regX1W1))
 	bw2s<- rnorm(N, bw2[2], SEslope(regX2W2))
 	
 	# generate fake y's from w's and slopes #
 	# y = b_yx * x + eps_yx, then substitute x = b_w1x1 * w1s + eps_w1x1 + b_w2x2 * w2s + eps_w2x2
 	yf<- bxs * (bw1s * w1s + rnorm(N, 0, sqrt(var(regX1W1))) +  bw2s * w2s + rnorm(N, 0, sqrt(var(regX2W2)))) + rnorm(N, 0, sqrt(var(regYX)))
 	return(sd(yf)) 	
 	
 }
 
 
 # SE when X2 is observed but X1 is estimated from W1, and then Y ~ I(X1+X2)
 SE.YfromW1X2.sim<- function(N=1e4, w1o, x2o, regYX, regX1W1, W1var=0.000471, X2var=0.000471)
 {
 	# get distribution of Ws, and slopes
 	w1s<- rnorm(N, w1o, sqrt(W1var))
 	
   	bw1<- coef(regX1W1)  # observed slopes
   	bx<- coef(regYX)
 	bxs<- rnorm(N, bx[2], SEslope(regYX))		
 	bw1s<- rnorm(N, bw1[2], SEslope(regX1W1))
 	 	
 	# generate fake y's from w's and slopes #
 	# y = b_yx * x + eps_yx, then substitute x = b_w1x1 * w1s + eps_w1x1 + b_w2x2 * w2s + eps_w2x2
 	yf<- bxs * (bw1s * w1s + rnorm(N, 0, sqrt(var(regX1W1))) +  rnorm(N, x20, sqrt(X2var))) + rnorm(N, 0, sqrt(var(regYX)))
 	return(sd(yf)) 	 	
 }

 # SE when X1 is observed but X2 is estimated from W2, and then Y ~ I(X1+X2)
 SE.YfromX1W2.sim<- function(N=1e4, x1o, w2o, regYX, regX2W2, X1var=0.000471, W2var=0.000471)
 {
 	# get distribution of Ws, and slopes
 	w2s<- rnorm(N, w2o, sqrt(W2var))

   	bw2<- coef(regX2W2)  
	bx<- coef(regYX)
 	bxs<- rnorm(N, bx[2], SEslope(regYX))		
 	bw2s<- rnorm(N, bw2[2], SEslope(regX2W2))
 	
 	# generate fake y's from w's and slopes #
 	# y = b_yx * x + eps_yx, then substitute x = b_w1x1 * w1s + eps_w1x1 + b_w2x2 * w2s + eps_w2x2
 	yf<- bxs * (rnorm(N, x10, sqrt(X1var)) +  bw2s * w2s + rnorm(N, 0, sqrt(var(regX2W2)))) + rnorm(N, 0, sqrt(var(regYX)))
 	return(sd(yf)) 	
 	
 }
 
 
  
 # regYX and must be lm (not gls!) object
 # Xvar is chosen to represent n = 1, CV = 5 on original scale, log10 transform 
 SE.YfromX.sim<- function(N=1e4, xo, regYX, Xvar=0.000471)
 {
 	# get distribution of Ws, and slopes
 	xs<- rnorm(N, xo, sqrt(Xvar))
	bx<- coef(regYX)
 	bxs<- rnorm(N, bx[2], SEslope(regYX))		
 	
 	# generate fake y's from w's and slopes #
 	# y = b_yx * x + eps_yx
 	yf<- bxs * xs + rnorm(N, 0, sqrt(var(regYX)))
 	return(sd(yf))
 }
 

 
 

 	
 