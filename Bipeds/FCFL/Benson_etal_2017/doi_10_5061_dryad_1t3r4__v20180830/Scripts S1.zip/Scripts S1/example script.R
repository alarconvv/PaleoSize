## example script for Benson et al, dinosaur body size manuscript
## show model fitting for one tree from the theropod data set (up to Aptian)
## the paper ran scripts like this for all trees in each dataset


 load('Example tree and data.RData')	# phy is tree, y is tip data
 source('Trend shift functions.R')
 
 # standard errors set to zero here for illustration, but should be set to realistic values
 
 # fit uniform models first 
 cat("Fitting uniform models...\n")
 bm<- fitContinuous(phy, y, SE=0, model="BM")
 tr<- fitContinuous(phy, y, SE=0, model="drift")	# uniform trend
 vs0<- tr$opt$sigsq 
 
 # fit multiTrend models with 1 and 2 temporal shifts
 # warning: it is slow to fit these models with more than 2 shifts
 VV<- vcv(phy)
 tipAges<- diag(VV)
 span<- 20	# regimes must last >= 20 Myr
 lowAge<- min(tipAges)+span
 hiAge<- max(tipAges)+span
 
 cat("\nFitting temporal shift models...\n")
 NC<- 6	# number of cores to use
 mt1<- opt.mTrendNP(phy, y, se=0, nreg=2, dt=3, mn.age=lowAge, mx.age=hiAge, min.span=span, ncore=NC, vs0=vs0)
 mt2<- opt.mTrendNP(phy, y, se=0, nreg=3, dt=3, mn.age=lowAge, mx.age=hiAge, min.span=span, ncore=NC, vs0=vs0)
 cat("\n\n")
 
 # trendShift models with 1,2,3 node shifts
 cat("Fitting node shift models...\n")
 ts1<- findBestShiftP(y, phy, se=0, vs.init=vs0, ncore=NC)
 ts2<- findBestShiftP(y, phy, se=0, bn=ts1$bn, vs.init=vs0, ncore=NC) 	# use previous solution for bn
 ts3<- findBestShiftP(y, phy, se=0, bn=ts2$bn, vs.init=vs0, ncore=NC) 	# use previous solution for bn
 
 # AICc vector
 aic.vec<- c(bm$opt$aicc, tr$opt$aicc, mt1$w$AICc, mt2$w$AICc, ts1$AICc, ts2$AICc, ts3$AICc)
 names(aic.vec)<- c("BM", "Trend","mTrend1", "mTrend2", "nodeShift1", "nodeShift2", "nodeShift3")
 daic<- aic.vec - min(aic.vec)
 print(daic)
 
 # visualize two models
 showMultiTrend(y, phy, w=mt1$w)	# best of the trendShift models by AICc
 showTrendShift(y, phy, w=ts1)		# best model overall