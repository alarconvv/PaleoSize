### Code to fit models of trends that can shift over time or across nodes
### by Gene Hunt, final version 2016-08-31
### used in Benson et al. (2017) Cope’s rule and the adaptive landscape of dinosaur body size evolution.

# fucntions to simulate, fit, and visualize the model of BM with a trend, 
#	in which the trend parameter (mu_s) can shift over time or across nodes on a tree
#
# Two classes of models:
#	(1) multiTrend = temporal shifts model of Benson et al
#		mu_s shared across all lineages, shifts at point(s) in time, which apply to 
#		all lineages extant at that time
#	(2) trendShift = node shift model of Benson et al
#		mu_s changes at node(s), which are inherited by descendants of those nodes
#	
#	- For both models, the BM variance is assumed to be shared across the whole tree
#	- Yes, "multiTrend" and "trendShift" are bad, uninformative names, but I don't 
#	want to risk error by changing them now
# 	- mclapply() is used for parallel computations, so parallel functions may not work 
#	when running R GUI (you must use command line R instead)

library(parallel)
library(mnormt)
library(ape)
library(geiger)
library(phytools)
library(phangorn)
library(paleoTS)


# simulate temporal shifts model
# tree is phylo object, tt is vector of shift points (with t[1] always = 0 for the base of the tree)
# pp are the parameters of the shift models, e.g., returned by the opt.mTrendXX functions
simMultiTrend<- function(tree, pp, tt)
{
	# map tree, get parameters
	treemap<- make.era.map(tree, tt)
	mp<- treemap$mapped.edge
	nr<- length(tt)	# number of regimes
	msv<- pp[1:nr]
	vs<- pp["vs"]
	x0<- pp["x0"]
	
	dx<- array(dim=dim(mp)) 	# changes in phenotype, by regime
	nb<- nrow(dx)				# number of branches (edges)
	for (i in 1:nr)		dx[,i]<- rnorm(nb, mean=msv[i]*mp[,i], sd=sqrt(vs*mp[,i]))
	DX<- apply(dx, 1, sum)	# sum by branch across regimes
	
	# sum over edges
	ed<- tree$edge
	parent<- ed[,1]
	child<- ed[,2]
	nt<- Ntip(tree)
	x<- numeric()

	for(i in 1:nt)
		{
			anc<- Ancestors(tree, i)
			anc<- c(anc, i)
			ok.edge<- parent %in% anc & child %in% anc
			x[i]<- x0 + sum(DX[ok.edge])	# sum changes over all branches leading to tips
		}
	names(x)<- tree$tip.label
	
	return(x)
}

# crude visualization of fitted multiTrend (temporal shifts) model
# x is vector of tip data, tree is phylo object, w is list returned by opt.mTrendXX functions
# - dots are tip values
# - thick line is expected (mean) value of the trait over time
# - thin lines show 95% probability interval
# - thin, grey line is lowess for comparison
showMultiTrend<- function(x, tree, w, line.col=rgb(1,0,0,0.5))
{
	# extract parameters
	pp<- w$par
	tt<- w$tt
	nomatch<- !(tree$tip.label %in% names(x))
	badtaxa<- tree$tip.label[nomatch]
	if(length(badtaxa)>0){
			cat("++Dropping tips not represented in data: ", badtaxa, "\n")
			tree<- drop.tip(tree, badtaxa)	}
	ta<- diag(vcv(tree))
	xs<- x[tree$tip.label]
	
	# get tiepoints for segments
	maxT<- max(ta)	
	tieX<- c(tt, maxT)
	ntp<- length(tieX)
	tieY<- array(dim=ntp)
	tieY[1]<- pp["x0"]
	msv<- pp[1:(ntp-1)]
	
	for(i in 2:ntp){
		tieY[i]<- tieY[i-1] + msv[i-1]*(tieX[i]-tieX[i-1])
		}
	
	# plot it #
	xl<- range(tieX)
	yl<- range(c(xs, tieY))
	
	plot(ta, xs, cex=1.5, pch=21, col="white", bg="black", xlim=xl, ylim=yl)
	segments(tieX[1:(ntp-1)], tieY[1:(ntp-1)], tieX[2:ntp], tieY[2:ntp], col=line.col, lwd=4)
	vs<- w$par["vs"]
	xo<- seq(tieX[1], maxT, length.out=200)
	aa<- approx(tieX, tieY, xout=xo)
	ee<- aa$y
	up<- ee + 1.96*sqrt(vs*xo)
	do<- ee - 1.96*sqrt(vs*xo)
	lines(xo, up, col=line.col)
	lines(xo, do, col=line.col)
	abline(v=tieX, lty=3, col=line.col)
	
	ll<- lowess(ta, xs)
	lines(ll, col="grey")
	
	invisible(list(tieX=tieX, tieY=tieY))
}


# function fits model with temporal shifts by exploring a range of shift points and retaining the best solution
# tree is phylo object, x is vector of tip data
# se is standard errors of tip values; if a single number, assumed to apply to all taxa.  Can also be a vector with
#	a value for each tip
# nreg is the number of regimes ( = number of shift points + 1)
# dt, mn.age, mx.age, min.span all specify the grid search over possible shift point hypotheses
#	- dt is the spacing of points
# 	- mn.age and mx.age are the minimum and maximum times that a shift is allowed to occur, in elapsed
#			time units from the base of the tree
#	- min.span is the minumum duration of a trend regime
# ncore is the number of cores for parallel proceesing (ncore=1 means no parallel)
# method refers to how the grid search is constructed; method="uniform" regularly spaces points from mn.age to mx.age, 
#		spaced by dt, subject to min.span. method="combined" takes this and adds the ages of terminal taxa as well (not much tested) 
# vs0 is an initially estimate of the BM variance and VV is vcv(tree); both are optional
opt.mTrendNP<- function(tree, x, se, nreg, dt, mn.age, mx.age, min.span, ncore=6, method=c("uniform", "combined"), vs0=NULL, VV=NULL)
{
	# get ready values to pass to logL, check for missing data
	if(length(se)==1)	se<- rep(se, length(x))
	if(is.null(VV))		VV<- vcv(tree)
	if(is.null(vs0))	vs0<- var(x)/max(diag(VV))
  	if (!identical(names(x), tree$tip.label))	stop("Names and order of traits and tree must match.")
 	  	
	# get shift tt
	method<- match.arg(method)
	ttm<- tt.matrix(nreg, mn.age, mx.age, dt, min.span, VV, method)
	ntt<- length(ttm)
	cat(ntt, "shift hypotheses to test.\n")
	
	if(ncore==1)	ww<- lapply(ttm, FUN=opt.mTrend.tt, tree=tree, x=x, se=se, VV=VV, vs0=vs0)
	else			ww<- mclapply(ttm, FUN=opt.mTrend.tt, tree=tree, x=x, se=se, VV=VV, vs0=vs0, mc.cores=ncore, mc.silent=TRUE)

	
	#for(i in 1:ntt)	{cat(i, "---\n"); print(ww[[i]])}
	
	
	logL<- sapply(ww, FUN=function(x)x$value)
	code<- sapply(ww, FUN=function(x)x$convergence)		
	best<- which.max(logL)
	tta<- t(sapply(ttm, FUN=function(x)x))
	res<- list(w=ww[[best]], logL=logL, tt=tta, code=code, wl=ww)
	return(res)
}


# fits a model of temporal shifts for a specific hypothesis of shift points
# tt is a vector of shift points; tt[1] = 0 always, so for example, a shift 50 time
# 	units after the base of the tree would be tt = c(0,50)
# users will generally not call directly, instead using opt.mTrendNP() to explore range of 
# 	shift point hypotheses
opt.mTrend.tt<- function(tt, tree, x, se, VV, vs0)  
 {
	cat(tt, "\n")
	treemap<- make.era.map(tree, tt)
	mC<- multiC(treemap)
	nreg<- length(tt)
	p0<- array(0, dim=nreg+2)
	p0[1:nreg]<- ms.guess(tree, x, VV, tt)
	#p0[nreg+1]<- vs0
	p0[nreg+1]<- log(vs0)
	p0[nreg+2]<- phyMean(x, VV)  
	names(p0)<- c(paste("ms", 1:nreg, sep=''), "vs", "x0")
	ll<- array(NA, dim=nreg+2)
	ll[nreg+1]<- 0  # lower bound on vs
	#cl<- list(fnscale=-1)
	#cl<- list(fnscale=-1, ndeps=rep(1e-8, nreg+2))
	#cl<- list(fnscale=-1, parscale=c(rep(1e-2, nreg), 1, 1e-2))
	#cl<- list(fnscale=-1, parscale=c(rep(1, nreg), 1e-3, 1))
	cl<- list(fnscale=-1, ndeps=c(rep(1e-4, nreg), 1e-2, 1e-4))
	

	#w<- optim(p0, fn=logL.mTrend, method="L-BFGS-B", lower=ll, control=cl, mC=mC, x=x, se=se)
	w<- try(optim(p0, fn=logL.mTrend, method="BFGS", control=cl, mC=mC, x=x, se=se))
	if(class(w)=="try-error")  {w<- list(); w$value=-Inf; w$convergence=-99}
	else{
		w$par["vs"]<- exp(w$par["vs"])  # convert back from log scale 
		w$tt<- tt
		w$p0<- p0
		w$p0["vs"]<- exp(p0["vs"])	
		w$AICc<- IC(w$value, K=length(w$par)+length(w$tt)-1, n=length(x))}
 	return(w)
 }


 # log-likelihood function, used by optimization functions
 logL.mTrend<- function(p, mC, x, se)  # mC is returned from multiC (for given tshifts)
 {
 	# gather parameters
 	nt<- length(x)
 	nreg<- length(mC)
 	ms<- p[1:nreg]
 	#vs<- p[nreg+1]
 	vs<- exp(p[nreg+1])
 	x0<- p[nreg+2]
 	
 	
 	# get expected mean and VCV matrix
 	MM<- ms[1]*diag(mC[[1]])
 	VV<- vs*mC[[1]]
 	for(i in 2:nreg)
 		{
 			MM<- MM + ms[i]*diag(mC[[i]])
 			VV<- VV + vs*mC[[i]]
 		}
 	VV<- VV + diag(se^2)
 	
 	#logl<- dmvnorm(x, mean=x0+MM, sigma=VV, log=TRUE)
 	logl<- dmnorm(x, mean=x0+MM, varcov=VV, log=TRUE)	# package mnormt faster by ~2x
 	
 	return(logl)
 	#return(list(MM=x0+MM, VV=VV))
 }
 
 # helper function
 phyMean<- function(x, VV)	{
	vec1<- rep(1, length(x))
	invVV<- solve(VV)
	aa<- solve(t(vec1)%*%invVV %*% vec1) %*%t (vec1) %*% invVV %*% x
	aat<- t(aa)
	return(aat)
	}

 # function to enumerate possible temporal shifts, subject to constraints
 # used by opt.mTrendNP
 tt.matrix<- function(nreg, mn.age, mx.age, dt, min.span, VV=NULL, method=c("uniform", "combined"))
 {
	method<- match.arg(method)
	tu<- seq(mn.age, mx.age, dt)
	if(method=="combined")	{
		if(is.null(VV))	stop("VV required if method==combined")
		ta<- diag(VV)
		tt<- sort(c(tu, ta))
		}	else					tt<- tu
	
	# get all combinations
	ttc<- combn(tt, m=nreg-1)  	# gets all combinations
	if(nreg==2)	nc<- length(ttc) else nc<- ncol(ttc)
	ttc0<- rbind(rep(0,nc), ttc)
	#print(ttc)
	#print(ttc0)
	dd<- apply(ttc0, 2, diff)	# get differences
	#print(dd)
	if(nreg>2)	mindd<- apply(dd, 2, min)	else mindd<- dd
	ok<- which(mindd >= min.span)
	ttcok<- t(ttc0[,ok])
	
	# convert to list for mclapply version
	ttfinal<- lapply(1:nrow(ttcok), function(i) ttcok[i,])
	
	return(ttfinal)
}

# generate initial estimates for mu_s parameters in trendShift models
# based on regression of tip values on elapsed time within each regime
ms.guess<- function(tree, x, VV=NULL, tt)
{
	nreg<- length(tt)
	ms0<- array(dim=nreg)
	if(is.null(VV))	VV<- vcv(tree)
	ta<- diag(VV)
	tt<- append(tt, max(ta)+1)
	for (i in 1:nreg)
		{
			sub<- ta>tt[i] & ta<=tt[i+1]
			if(sum(sub)>2)	{ wr<- lm(x ~ ta, subset=sub); ms0[i]<- coef(wr)[2]} else ms0[i]<- 0
		}
	ms0[is.na(ms0)]<- 0
	return(ms0)	
}

#####################################################################
### functions below needed for trendShift (=node shift) analyses ####
#####################################################################

# simulates trait evolution with a node-shift in the trend parameter
#  tree is a phylo object, pp are parameters of model (e.g., as returned by findBestShift)
#  bn is a vector of node numbers at which a shift occurs
#  stem=1 sets the shift at the base of the branch supporting each node; stem=0 sets
#		the shift to be at the top of the branch 
simTrendShift<- function(tree, pp, bn, stem=1)
{
	# currently, only works for vs shared across regimes #
	
	# get paramaters, map tree #
	nreg<- length(bn)+1	# number of regimes
	msv<- pp[1:nreg]
	vs<- pp["vs"]
	x0<- pp["x0"]

	#treemap<- make.era.map(tree, tt)
	#mp<- treemap$mapped.edge
	trm<- tree
  	for (i in 1:(nreg-1))
		trm<- paintSubTree(trm, node=bn[i], state=i+1, stem=stem)
	trm<- orderMappedEdge(trm, ordering="numerical")
	mp<- trm$mapped.edge
	
	dx<- array(dim=dim(mp)) 	# changes in phenotype, by regime
	nb<- nrow(dx)				# number of branches (edges)
	for (i in 1:nreg)		dx[,i]<- rnorm(nb, mean=msv[i]*mp[,i], sd=sqrt(vs*mp[,i]))
	DX<- apply(dx, 1, sum)	# sum by branch across regimes
	
	# sum over edges
	ed<- tree$edge
	parent<- ed[,1]
	child<- ed[,2]
	nt<- Ntip(tree)
	x<- numeric()

	for(i in 1:nt)
		{
			anc<- Ancestors(tree, i)
			anc<- c(anc, i)
			ok.edge<- parent %in% anc & child %in% anc
			x[i]<- x0 + sum(DX[ok.edge])	# sum changes over all branches leading to tips
		}
	names(x)<- tree$tip.label
	
	return(x)
		
}


# simple visualization of the node-shift model
#  	x is vector of tip values, tree is phylo onject, w is output of findBestShiftP
#	output is two panel figure
#	- right panel is tree, with regimes mapped to terminal taxa
#	- left panel plots tip values by regime; squares are ancestral states (crudely, assuming BM) colored by 
#		each regime (root of tree is white square)
#	- legend gives regime color and mu_s estimate in brackets
showTrendShift<- function(x, tree, w, leg.place="topleft")
{
	# match tips
	nomatch<- !(tree$tip.label %in% names(x))
	badtaxa<- tree$tip.label[nomatch]
	#cat("++Dropping tips not represented in data: ", badtaxa, "\n")
	treed<- drop.tip(tree, badtaxa)
	ta<- diag(vcv(treed))
	xs<- x[treed$tip.label]	
	
	# extract parameters, determine colors
	pp<- w$par
	bn<- w$bn
	nbn<- length(bn)
	cols<- c("black", "red", "blue", "lightgreen", "tan", "yellow", "violet", "pink", "brown", "lightblue", "green", "grey")
	ddl<- Descendants(treed, node=bn, type="tips")
	reg<- rep(1, length(xs))
	#tip.col<- rep(cols[1], length(xs))

	for(i in 1:nbn){
		de<- ddl[[i]]
		reg[ddl[[i]]]<- i+1
		#tip.col[ddl[[i]]]<- cols[i+1]
		}
	tip.col<- cols[reg]
	names(tip.col)<- names(reg)<- names(xs)
		
	# do plots
	layout(t(1:2))
	VV<- vcvPhylo(treed, anc.nodes=TRUE)
	all.ages<- diag(VV)
	
	plot(ta, xs, pch=21, bg=tip.col, cex=1.5, xlim=c(0, max(all.ages)))
	rlab<- paste0("regime", 1:(nbn+1), " [", signif(pp[1:(nbn+1)], 2), "]")
	legend(x=leg.place, legend=rlab, pch=21, pt.bg=cols[1:(nbn+1)], cex=0.7)
	aa<- ace(xs, treed, CI=FALSE)
	chlab<- as.character(bn)
	nage<- all.ages[chlab]
	size.anc<- aa$ace[chlab]
	points(nage, size.anc, pch=22, bg=cols[2:(nbn+1)], cex=2)
	points(0, pp["x0"], pch=22, bg="white", cex=2)	
	plot(treed, cex=0.6, label.offset=2)
	tiplabels(pch=21, bg=tip.col, cex=1.0)
		
	invisible(reg)
}


# function to fit model of trend with node-shift.  Tests all possible next shifts in addition to bn and 
#	retains best one.
# x, tree, se, stem as above
# bn is vector of branch shifts already found; bn=NULL if looking for first shift
# vs.init is initial guess of BM variance parameter
# vs.share=TRUE if BM variance is shared across regimes; if FALSE, each regime has its own BM variance (not recommended)
findBestShiftP<- function(x, tree, se, bn=NULL, vs.init=NULL, ncore=6, cl=NULL, stem=1, vs.share=TRUE)
{
	if(!is.null(bn)){
			nreg<- length(bn)+1
			trm<- tree
			for (i in 1:(nreg-1))	
				trm<- paintSubTree(trm, node=bn[i], state=i+1, stem=stem)
	} else nreg=1
	
	if(length(se)==1)	se<- rep(se, length(x))
	
	allNodes<- (Ntip(tree)+2):(Ntip(tree)+Nnode(tree))
	prev<- allNodes %in% bn
	allNodes<- allNodes[!prev]
	nn<- length(allNodes)
	cat("Trying ", nn, " possible shift points\n")
	
	# set-up and run parallel fits
	bnList<- list()
	for(i in 1:nn)	bnList[[i]]<- sort(c(bn, allNodes[i]))
	if(vs.share)	ww<- mclapply(bnList, FUN=opt.trendShift, x=x, tree=tree, se=se, stem=stem, vs.init=vs.init, cl=cl, mc.cores=ncore, mc.silent=TRUE, silent=TRUE)
	else 			ww<- mclapply(bnList, FUN=opt.trendShift.vs, x=x, tree=tree, se=se, stem=stem, vs.init=vs.init, cl=cl, mc.cores=ncore, mc.silent=TRUE)
	
	
	# find which wins
	ll<- sapply(ww, FUN=function(x) x$logL)
	best<- which.max(ll)
	#bnl<- lapply(allNodes, FUN=function(x) sort(c(x, bn)))
	w<- ww[[best]]
	w$bn<- bnList[[best]]
	w$all.logl<- ll
	w$allNodes<- allNodes
	w$code<- sapply(ww, FUN=function(x)x$code)
	w$wl<- ww
	
	return(w)
}

# fits model of Trend with node-shift for a specific hypothesis of where the node shift occurs
# generally not used directly by user; called by findBestShiftP
opt.trendShift<- function(bn, x, tree, se, vs.init=NULL, cl=NULL, stem=1, hess=FALSE, silent=FALSE)
{
	# get ready values to pass to logL, check for missing data
	if(!silent)	cat(bn, '\n')
	if(length(se)==1)	se<- rep(se, length(x))
	if (!identical(names(x), tree$tip.label))	stop("Names and order of traits and tree must match.")
	
	# initial estimates and calculations, VV, CC 
	if(length(se)==1)	se<- rep(se, length(x))
	VV<- vcv(tree)
	nt<- Ntip(tree)
	if(is.null(vs.init))	vs.init<- var(x)/mean(diag(VV))  # very rough guess
	nreg<- length(bn) + 1   # no. regimes = no. shifts + 1
	trm<- tree
  	for (i in 1:(nreg-1))
		trm<- paintSubTree(trm, node=bn[i], state=i+1, stem=stem)
	trm<- orderMappedEdge(trm, ordering="numerical")
	CC<- multiC(trm)
	mmi<- matrix(nrow=nreg, ncol=nt)
	for (i in 1:nreg)
		mmi[i,]<- diag(CC[[i]])  # converts to a matrix
	
	# set up p vector
    #p0<- c(rep(0,nreg), vs.init, phyMean(x, VV))
    p0<- c(rep(0,nreg), log(vs.init), phyMean(x, VV))
	names(p0)<- c(paste("ms", 1:nreg, sep=""), "vs", "x0")
	
	# control list
	if(is.null(cl))	cl<- list(fnscale= -1)
	#lb<- rep(NA, length(p0))		# uncomment to switch to L-BFGS-B
	#lb[nreg+1]<- 1e-6
	#w<- optim(p0, logL.trendShift, method="L-BFGS-B", lower=lb, control=cl, hessian=hess, bn=bn, mmi=mmi, x=x, VV=VV, se=se)
	w<- optim(p0, logL.trendShift, method="Nelder", control=cl, hessian=hess, bn=bn, mmi=mmi, x=x, VV=VV, se=se)
	w$par["vs"]<- exp(w$par["vs"])  # convert back

	# organize results
	K<- nreg*2 + 1  # assumes shift not speciefied ahead of time
	n<- length(x)
	if(hess)	wse<- sqrt(diag(-1 * solve(w$hessian)))		# SE's from hessian, if asked for
	else		wse<- rep(NA, K)
	
	res<- list(logL=w$value, AICc=IC(w$value, K, n), parameters=w$par, se=wse, modelName=paste("trendShift", nreg, sep="."), n=n, K=K, code=w$convergence)

	return(res)	
}

# same as previous, but assumes a separate BM variance parameter for each regime
opt.trendShift.vs<- function(x, tree, se, bn, vs.init=NULL, cl=NULL, stem=1, hess=FALSE, silent=FALSE)
{
	# get ready values to pass to logL, check for missing data
	if(length(se)==1)	se<- rep(se, length(x))
	if (!identical(names(x), tree$tip.label))	stop("Names and order of traits and tree must match.")

	# initial estimates and calculations, VV, CC 
	if(length(se)==1)	se<- rep(se, length(x))
	VV<- vcv(tree)
	nt<- Ntip(tree)
	if(is.null(vs.init))	vs.init<- var(x)/mean(diag(vcv(tree)))  # very rough guess
	nreg<- length(bn) + 1   # no. regimes = no. shifts + 1
	trm<- tree
  	for (i in 1:(nreg-1))
		trm<- paintSubTree(trm, node=bn[i], state=i+1, stem=stem)
	trm<- orderMappedEdge(trm, ordering="numerical")
	CC<- multiC(trm)
	mmi<- matrix(nrow=nreg, ncol=nt)
	for (i in 1:nreg)
		mmi[i,]<- diag(CC[[i]])  # converts to a matrix
	
	# set up p vector
	#p0<- c(rep(0,nreg), rep(vs.init, nreg), phyMean(x,VV))
	p0<- c(rep(0,nreg), log(rep(vs.init, nreg)), phyMean(x,VV))
	names(p0)<- c(paste("ms", 1:nreg, sep=""), paste("vs", 1:nreg, sep=""), "x0")
	
	# control list
	pscl<- c(rep(20, nreg), rep(20, nreg), 1)
	nd<- c(rep(1e-5, nreg*2), 1e-3)
	if(is.null(cl))	cl<- list(fnscale= -1, parscale=1/pscl, ndeps=nd, lmm=10)
	
	#w<- optim(p0, logL.trendShift.vs, method="BFGS", control=cl, hessian=hess, bn=bn, mmi=mmi, x=x, CC=CC, se=se)
	w<- optim(p0, logL.trendShift.vs, method="Nelder", control=cl, hessian=hess, bn=bn, mmi=mmi, x=x, CC=CC, se=se)	
	w$par["vs"]<- exp(w$par["vs"])  # convert back
	
	# organize results
	K<- nreg*3  # assumes shift not specified ahead of time
	n<- length(x)
	if(hess)	wse<- sqrt(diag(-1 * solve(w$hessian)))		# SE's from hessian, if asked for
	else		wse<- rep(NA, K)
	
	res<- list(logL=w$value, AICc=IC(w$value, K, n), parameters=w$par, se=wse, modelName=paste("trendShift", nreg, sep="."), n=n, K=K, code=w$convergence)

	return(res)	
}

# log-likelihood function for trend with node shift (vs shared across regimes)
logL.trendShift<- function(p, x, VV, mmi, se, bn)
{
	# gather parameters from p; assumes vs is shared over whole tree
	# note nodes for shift (bn) are not optimized; they are set for a given optimization
	nreg<- length(bn)+1  # number of regimes = no. of shift points + 1
	ms<- p[1:nreg]
	#vs<- p[nreg+1]
	vs<- exp(p[nreg+1])
	x0<- p[nreg+2]
	
	
	# get vector of means for tips from this, then logL
	MM<- x0 + colSums(ms*mmi)
	#cat(p, "[")
	VVt<- vs*VV + diag(se^2)  # add sampling error to VCV matrix
	#logl<- dmvnorm(x, mean=MM, sigma=VVt, log=TRUE)
	logl<- dmnorm(x, mean=MM, varcov=VVt, log=TRUE)  # mnormt faster ~2x
	#logl<- fastdmvnorm(x, mean=MM, sigma=VVt)
	#cat(logl, "]\n")
	
	return(logl)	
}

# log-likelihood function for trend with node shift (vs separate across regimes)
logL.trendShift.vs<- function(p, x, mmi, CC, se, bn)
{
	# gather parameters from p; assumes vs is separate for each regime
	# note nodes for shift (bn) are not optimized; they are set for a given optimization
	nreg<- length(bn)+1  # number of regimes = no. of shift points + 1
	ms<- p[1:nreg]
	#vs<- p[(nreg+1):(2*nreg)]
	vs<- exp(p[(nreg+1):(2*nreg)])
	x0<- p[2*nreg+1]
	#cat(ms, vs, x0, '\t')
	#cat(dim(mmi))
	
	# get vector of means for tips from this, then logL
	MM<- x0 + colSums(ms*mmi)
	VVt<- vs[1]*CC[[1]]
	for(i in 2:nreg)
		VVt<- VVt + vs[i]*CC[[i]]
	VVt<- VVt + diag(se^2)  # add sampling error to VCV matrix

	#logl<- dmvnorm(x, mean=MM, sigma=VVt, log=TRUE)
	logl<- dmnorm(x, mean=MM, varcov=VVt, log=TRUE)
	#logl<- fastdmvnorm(x, mean=MM, sigma=VVt)

	
	return(logl)	
}


